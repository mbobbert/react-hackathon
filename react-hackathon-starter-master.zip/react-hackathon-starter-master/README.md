# react-hackathon-starter
Starter template for the React hackathon
